package com.sujata.producer;

public class Tabla implements Instrument {

	@Override
	public void play() {
		System.out.println("DHIN TAK TAK !!!");

	}

}
