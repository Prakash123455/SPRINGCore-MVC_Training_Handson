package com.sujata.producer;

public interface Performer {

	public void perform();
}
