package com.sujata.producer;

public interface Greet {
	public void wish(String name);

}
